
# Birthday Site

A personalized birthday website with a message, image gallery, and music. Hosted for free using GitHub Pages.

## How to View

Visit: `https://<your-username>.github.io/birthday-site/`

## How to Edit

1. Fork this repository or clone it to your machine.
2. Add or replace images inside the `images/` folder.
3. Replace or add audio files in the `audio/` folder.
4. Edit `index.html` for content changes.

## Author

Made with ❤️ by SUSA
